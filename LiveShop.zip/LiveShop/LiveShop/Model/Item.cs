﻿namespace LiveShop.Model
{
    public class Item
    {
        public Car Car { get; set; }
        public int Quantity { get; set; }
    }
}
